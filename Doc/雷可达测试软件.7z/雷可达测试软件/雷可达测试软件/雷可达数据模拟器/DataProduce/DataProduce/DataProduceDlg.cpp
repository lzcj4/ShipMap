
// DataProduceDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DataProduce.h"
#include "DataProduceDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDataProduceDlg �Ի���




CDataProduceDlg::CDataProduceDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDataProduceDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDataProduceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_ListView);
}

BEGIN_MESSAGE_MAP(CDataProduceDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SET, &CDataProduceDlg::OnBnClickedButtonSet)
//	ON_BN_CLICKED(IDC_BUTTON2, &CDataProduceDlg::OnBnClickedButton2)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_SINGLE, &CDataProduceDlg::OnBnClickedButtonSingle)
	ON_BN_CLICKED(IDC_BUTTON_FIVE, &CDataProduceDlg::OnBnClickedButtonFive)
	ON_BN_CLICKED(IDC_BUTTON_TEN, &CDataProduceDlg::OnBnClickedButtonTen)
END_MESSAGE_MAP()


// CDataProduceDlg ��Ϣ��������

BOOL CDataProduceDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	m_nCount = 0;
	m_nIndex = 0;
	ZeroMemory(m_tar, 10*sizeof(TARGETPARAM));
	GetCurrentDirectory(255, m_tPath);
	CString strPath = m_tPath; 
	strPath += PARAMCONFIG_PATH;
	
	TCHAR tch[255];
	DWORD dwRetval = GetPrivateProfileString(_T("GPS"), _T("latitude"), _T("30.4"), tch, 255, strPath);
	m_lat = tch;
	dwRetval = GetPrivateProfileString(_T("GPS"), _T("longitude"), _T("114.4"), tch, 255, strPath);
	m_long = tch;
	dwRetval = GetPrivateProfileString(_T("GPS"), _T("altitude"), _T("45.0"), tch, 255, strPath);
	m_alti = tch;

	((CEdit *)GetDlgItem(IDC_EDIT_LAT))->SetWindowTextW(m_lat);
	((CEdit *)GetDlgItem(IDC_EDIT_LONG))->SetWindowTextW(m_long);
	((CEdit *)GetDlgItem(IDC_EDIT_ALTI))->SetWindowTextW(m_alti);


	m_RecvParam.psocket = &m_tSocket;
	m_RecvParam.hwnd = this->GetSafeHwnd();

	m_tSocket.LoadSocket();
	m_tSocket.m_ulRemoteIP = 0xc0a8006e;
	m_tSocket.m_usRemotePort = 0x3930;
	m_tSocket.m_ulLocalIP = 0xc0a8006e;
	m_tSocket.m_usLocalPort = 0x3a30;
	


	LVCOLUMN column[9];
	column[0].pszText = L"����";
	column[1].pszText = L"����";
	column[2].pszText = L"γ��";
	column[3].pszText = L"����";
	column[4].pszText = L"����";
	column[5].pszText = L"��λ";
	column[6].pszText = L"�߶�";
	column[7].pszText = L"�ٶ�";
	column[8].pszText = L"����";

	RECT rct;
	m_ListView.GetWindowRect(&rct);
	int nWidth = (int)(rct.right - rct.left)/9;
	for(int i = 0 ; i < 9; i++)
	{
		column[i].mask = LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM|LVCFMT_CENTER;//�б��ӿؼ�������
		column[i].fmt = LVCFMT_LEFT;			
		column[i].cx = nWidth;
		column[i].iSubItem = i;
		m_ListView.InsertColumn(i, &column[i]);
	}
	m_ListView.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES|LVS_EX_FLATSB);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CDataProduceDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CDataProduceDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CDataProduceDlg::OnBnClickedButtonSet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	((CEdit *)GetDlgItem(IDC_EDIT_LAT))->GetWindowTextW(m_lat);
	((CEdit *)GetDlgItem(IDC_EDIT_LONG))->GetWindowTextW(m_long);
	((CEdit *)GetDlgItem(IDC_EDIT_ALTI))->GetWindowTextW(m_alti);

	CString strPath = m_tPath; 
	strPath += PARAMCONFIG_PATH;

	WritePrivateProfileString(_T("GPS"), _T("latitude "), m_lat, strPath);
	WritePrivateProfileString(_T("GPS"), _T("longitude  "), m_long, strPath);
	WritePrivateProfileString(_T("GPS"), _T("altitude  "), m_alti, strPath);
}


//void CDataProduceDlg::OnBnClickedButton2()
//{
//	// TODO: �ڴ����ӿؼ�֪ͨ�����������
// 	m_tSocket.m_nSendLen = 10;
// 	for(int i = 0;i < 10; i++)
// 	{
// 		m_tSocket.m_chSendBuf[i] = i;
// 	}
// 	m_tSocket.TcpSend();
//}


void CDataProduceDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	switch(nIDEvent)
	{
	case 1:
		{
			int nIndex = 0;
			CString str;
			m_tSocket.m_chSendBuf[nIndex++] = 0xaa;
			m_tSocket.m_chSendBuf[nIndex++] = 0xaa;
			m_tSocket.m_chSendBuf[nIndex++] = 0xaa;
			m_tSocket.m_chSendBuf[nIndex++] = 0xaa;
			b_f bf;
			bf.f = (float)m_nCount;
			memcpy_s(m_tSocket.m_chSendBuf+nIndex, 4, bf.by, 4);
			nIndex += 4;
			float x, y;
			for(int i = 0; i < m_nCount; i++)
			{
				m_tar[i].fR.f = m_tar[i].fR.f + m_tar[i].fV.f;
				Az_Range_2_GPS(m_tar[i].fA.f, m_tar[i].fR.f, x, y);
				WGS84_to_GCJ02(x, y, m_tar[i].fLat.f, m_tar[i].fLong.f);
				m_tar[i].fAlti.f = m_tar[i].fH.f + _wtof(m_alti);
				memcpy_s(m_tSocket.m_chSendBuf+nIndex, sizeof(TARGETPARAM), m_tar+i, sizeof(TARGETPARAM));
				nIndex += 64;
				str.Format(L"%d", m_nIndex);
				m_ListView.InsertItem(m_nIndex, str);
				str.Format(L"%f", m_tar[i].fLong.f);
				m_ListView.SetItemText(m_nIndex, 1, str);
				str.Format(L"%f", m_tar[i].fLat.f);
				m_ListView.SetItemText(m_nIndex, 2, str);
				str.Format(L"%.1f", m_tar[i].fAlti.f);
				m_ListView.SetItemText(m_nIndex, 3, str);
				str.Format(L"%.1f", m_tar[i].fR.f);
				m_ListView.SetItemText(m_nIndex, 4, str);
				str.Format(L"%.1f", m_tar[i].fA.f);
				m_ListView.SetItemText(m_nIndex, 5, str);
				str.Format(L"%.1f", m_tar[i].fH.f);
				m_ListView.SetItemText(m_nIndex, 6, str);
				str.Format(L"%.1f", m_tar[i].fV.f);
				m_ListView.SetItemText(m_nIndex, 7, str);
				str.Format(L"%.1f", m_tar[i].fDirect.f);
				m_ListView.SetItemText(m_nIndex, 8, str);
				m_ListView.EnsureVisible(m_nIndex, TRUE);

				m_nIndex++;
			}
			m_tSocket.m_nSendLen = 8+m_nCount*64;
			m_tSocket.TcpSend();
		}
		break;
	default:
		break;
	}
	CDialogEx::OnTimer(nIDEvent);
}


void CDataProduceDlg::OnBnClickedButtonSingle()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	KillTimer(1);
	srand((unsigned) time(NULL));
	m_tar[0].fR.f = 300.f + rand()%1000 / 10.f;
	m_tar[0].fA.f = rand()%3600 / 10.f;
	m_tar[0].fH.f = 30.f + rand()%1000 / 10.f;
	m_tar[0].fV.f = 5.f + rand()%100 / 10.f;
	m_tar[0].fDirect.f = rand()%3600 / 10.f;

	m_nCount = 1;
	SetTimer(1, 330, NULL);
}

void CDataProduceDlg::Az_Range_2_GPS(float Az, float Rn, float &lat, float &lng)
{
	JWD A(_wtof(m_long), _wtof(m_lat));

	double dx = Rn * sin(Az * PI /180.);
	double dy = Rn * cos(Az * PI /180.);

	lng = (dx/A.Ed + A.m_RadLo) * 180./PI;
	lat = (dy/A.Ec + A.m_RadLa) * 180./PI;
}


bool CDataProduceDlg::out_of_china(float x, float y)
{
	if (y < 72.004 || y > 137.8347)
		return true;
	if (x < 0.8293 || x > 55.8271)
		return true;
	return false;
}

float CDataProduceDlg::transformLat(float x, float y)
{
	// 	x -= 105.0f;
	// 	y -= 35.0;

	double ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * sqrt(abs(x));
	ret += (20.0 * sin(6.0 * x * PI) + 20.0 * sin(2.0 * x * PI)) * 2.0 / 3.0;
	ret += (20.0 * sin(y * PI) + 40.0 * sin(y / 3.0 * PI)) * 2.0 / 3.0;
	ret += (160.0 * sin(y / 12.0 * PI) + 320 * sin(y * PI / 30.0)) * 2.0 / 3.0;

	return ret;
}

float CDataProduceDlg::transformLng(float x, float y)
{
	// 	x -= 105.0f;
	// 	y -= 35.0;

	float ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * sqrt(abs(x));
	ret += (20.0 * sin(6.0 * x * PI) + 20.0 * sin(2.0 * x * PI)) * 2.0 / 3.0;
	ret += (20.0 * sin(x * PI) + 40.0 * sin(x / 3.0 * PI)) * 2.0 / 3.0;
	ret += (150.0 * sin(x / 12.0 * PI) + 300.0 * sin(x / 30.0 * PI)) * 2.0 / 3.0;

	return ret;
}

void CDataProduceDlg::WGS84_to_GCJ02(float x, float y, float &m, float &n)
{
	if (out_of_china(x, y))
	{
		m = x;
		n = y;
		return ;
	}

	float dLat = transformLat(y - 105.f, x-35.f);
	float dLng = transformLng(y - 105.f, x-35.f);

	float radLat = x / 180.0f * PI;
	float magic = sin(radLat);
	magic = 1 - ELLIPSOID_ECCENTRICITY * magic * magic;
	float sqrtMagic = sqrt(magic);

	dLat = (dLat * 180.0f) / ((SAT_TO_COOR * (1 - ELLIPSOID_ECCENTRICITY)) / (magic * sqrtMagic) * PI);
	dLng = (dLng * 180.0f) / (SAT_TO_COOR / sqrtMagic * cos(radLat) * PI);

	m = x + dLat;
	n = y + dLng;
}


void CDataProduceDlg::OnBnClickedButtonFive()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	KillTimer(1);
	srand((unsigned) time(NULL));
	m_nCount = 5;
	for (int i = 0; i < m_nCount; i++)
	{
		m_tar[i].fR.f = 300.f + rand()%1000 / 10.f;
		m_tar[i].fA.f = rand()%3600 / 10.f;
		m_tar[i].fH.f = 30.f + rand()%1000 / 10.f;
		m_tar[i].fV.f = 5.f + rand()%100 / 10.f;
		m_tar[i].fDirect.f = rand()%3600 / 10.f;
	}

	SetTimer(1, 330, NULL);
}


void CDataProduceDlg::OnBnClickedButtonTen()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	KillTimer(1);
	srand((unsigned) time(NULL));
	m_nCount = 10;
	for (int i = 0; i < m_nCount; i++)
	{
		m_tar[i].fR.f = 300.f + rand()%1000 / 10.f;
		m_tar[i].fA.f = rand()%3600 / 10.f;
		m_tar[i].fH.f = 30.f + rand()%1000 / 10.f;
		m_tar[i].fV.f = 5.f + rand()%100 / 10.f;
		m_tar[i].fDirect.f = rand()%3600 / 10.f;
	}

	SetTimer(1, 330, NULL);
}
