
// DataProduceDlg.h : ͷ�ļ�
//

#pragma once
#define PARAMCONFIG_PATH _T("/ini/Config.ini")
#include "TSocket.h"
#include <math.h>

#define SAT_TO_COOR 6378245.0	//������������ͶӰ��ƽ���ͼ����ϵ��ͶӰ����
#define ELLIPSOID_ECCENTRICITY 0.00669342162296594323
#define PI 3.14159265358979

typedef union B_F{
	float f;
	byte by[4];
}b_f;

struct TARGETPARAM{
	b_f fLat;
	b_f fLong;
	b_f fAlti;
	b_f fR;
	b_f fA;
	b_f fH;
	b_f fV;
	b_f fDirect;
	b_f fReserve[8];
};

static double Rc = 6378137;  // ����뾶
static double Rj = 6356725;  // ���뾶 

class JWD
{
public:
	double m_LoDeg, m_LoMin, m_LoSec;  // longtitude ����
	double m_LaDeg, m_LaMin, m_LaSec;
	double m_Longitude, m_Latitude;
	double m_RadLo, m_RadLa;
	double Ec;
	double Ed;
public:

	// ���캯��, ����: loDeg ��, loMin ��, loSec ��;  γ��: laDeg ��, laMin ��, laSec��
	JWD(double loDeg, double loMin, double loSec, double laDeg, double laMin, double laSec)
	{
		m_LoDeg=loDeg; m_LoMin=loMin; m_LoSec=loSec; m_LaDeg=laDeg; m_LaMin=laMin; m_LaSec=laSec;
		m_Longitude = m_LoDeg + m_LoMin / 60 + m_LoSec / 3600;
		m_Latitude = m_LaDeg + m_LaMin / 60 + m_LaSec / 3600;
		m_RadLo  = m_Longitude * PI / 180.;
		m_RadLa  = m_Latitude * PI / 180.;
		Ec = Rj + (Rc - Rj) * (90.- m_Latitude) / 90.;
		Ed = Ec * cos(m_RadLa);
	}

	//��
	JWD(double longitude, double latitude)
	{
		m_LoDeg = int(longitude);
		m_LoMin = int((longitude - m_LoDeg)*60);
		m_LoSec = (longitude - m_LoDeg - m_LoMin/60.)*3600;

		m_LaDeg = int(latitude);
		m_LaMin = int((latitude - m_LaDeg)*60);
		m_LaSec = (latitude - m_LaDeg - m_LaMin/60.)*3600;

		m_Longitude = longitude;
		m_Latitude = latitude;
		m_RadLo = longitude * PI/180.;
		m_RadLa = latitude * PI/180.;
		Ec = Rj + (Rc - Rj) * (90.-m_Latitude) / 90.;
		Ed = Ec * cos(m_RadLa);
	}
};

// CDataProduceDlg �Ի���
class CDataProduceDlg : public CDialogEx
{
// ����
public:
	CDataProduceDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_DATAPRODUCE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

	TSocket m_tSocket;
	RECVPARAM m_RecvParam;

private:
	TCHAR m_tPath[255];
	CString m_lat;
	CString m_long;
	CString m_alti;

	CListCtrl m_ListView;

	TARGETPARAM m_tar[10];
	
	int m_nCount;
	LONGLONG m_nIndex;
// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonSet();
//	afx_msg void OnBnClickedButton2();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonSingle();

	void Az_Range_2_GPS(float Az, float Rn, float &lat, float &lng);
	bool out_of_china(float x, float y);
	float transformLat(float x, float y);
	float transformLng(float x, float y);
	void WGS84_to_GCJ02(float x, float y, float &m, float &n);

	afx_msg void OnBnClickedButtonFive();
	afx_msg void OnBnClickedButtonTen();
};
