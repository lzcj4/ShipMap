
// RecDataDlg.h : ͷ�ļ�
//
#include "TSocket.h"
#pragma once

// typedef union B_F{
// 	float f;
// 	byte by[4];
// }b_f;

struct TARGETPARAM{
	b_f fLat;
	b_f fLong;
	b_f fAlti;
	b_f fR;
	b_f fA;
	b_f fH;
	b_f fV;
	b_f fDirect;
	b_f fReserve[8];
};


// CRecDataDlg �Ի���
class CRecDataDlg : public CDialogEx
{
// ����
public:
	CRecDataDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_RECDATA_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

	TSocket m_tSocket;
	CListCtrl m_ListView;

	RECVPARAM m_RecvParam;

	TARGETPARAM m_tar[10];

	LONGLONG m_nIndex;


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

	afx_msg LRESULT Recv(WPARAM wParam, LPARAM lParam);
};
